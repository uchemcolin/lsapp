    <?php $__env->startSection("content"); ?>
        <h1>Services</h1>
        <ul class="list-group">
            <?php $__currentLoopData = $designs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $design): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item"><?php echo e($design); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts/app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mysites\lsapp\resources\views/pages/services.blade.php ENDPATH**/ ?>