<?php $__env->startSection("content"); ?>
<br/>
    <h1>Edit Post</h1>
    <?php echo e(Form::open(["action" => ["PostsController@update", $post->id], "method" => "POST"])); ?>

        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" class="form-control" name="title" id="title" aria-describedby="titleHelp" placeholder="Enter the title" maxlength="191" value="<?php echo e($post->title); ?>">
        </div>
        <div class="form-group">
            <label for="body">Body</label>
            <textarea class="form-control" name="body" id="article-ckeditor" rows="5" placeholder="Enter the body of the post"><?php echo e($post->body); ?></textarea>
        </div>
        <?php echo e(Form::hidden("_method", "PUT")); ?>

        <button type="submit" class="btn btn-primary">Submit</button>
    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mysites\lsapp\resources\views/posts/edit.blade.php ENDPATH**/ ?>