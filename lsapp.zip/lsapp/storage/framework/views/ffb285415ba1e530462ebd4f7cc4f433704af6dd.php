<?php $__env->startSection("content"); ?>
<br/>
    <h1>Posts</h1>
    <?php if(count($posts) > 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4">
                            <img style="width:100%" src="/storage/cover_images/<?php echo e($post->cover_image); ?>"/>
                        </div>
                        <div class="col-md-8">
                            <a href="/posts/<?php echo e($post->id); ?>"><h3><?php echo e($post->title); ?></h3></a>
                            <small>Written on <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <br/>
        <?php echo e($posts->links()); ?>

    <?php else: ?>
        <p>There are currently no posts</p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mysites\lsapp\resources\views/posts/index.blade.php ENDPATH**/ ?>