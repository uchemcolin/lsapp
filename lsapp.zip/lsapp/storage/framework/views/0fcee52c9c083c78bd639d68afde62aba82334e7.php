    <?php $__env->startSection("content"); ?>
        <h1>About</h1>
        <p>Re-learning Laravel</p>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts/app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mysites\lsapp\resources\views/pages/about.blade.php ENDPATH**/ ?>