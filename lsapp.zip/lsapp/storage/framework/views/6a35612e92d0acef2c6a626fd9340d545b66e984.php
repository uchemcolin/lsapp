<?php $__env->startSection("content"); ?>
<br/>
    <?php if(!empty($post)): ?>
        <a href="/posts" class="btn btn-dark">Back</a>
        <h1><?php echo e($post->title); ?></h1>
        <div>
            <img class="w-100" src="/storage/cover_images/<?php echo e($post->cover_image); ?>"/>
            <?php echo $post->body; ?>

        </div>
        <hr/>
        <small>Written on <?php echo e($post->created_at); ?> by <?php echo e($post->user->name); ?></small>
        <hr/>
        <?php if(!Auth::guest()): ?>
            <?php if(Auth::user()->id == $post->user_id): ?>
                <div class="row">
                    <div class="col-md-6">
                        <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-primary">Edit</a>
                    </div>
                    <div class="col-md-6">
                        <?php echo e(Form::open(["action" => ["PostsController@destroy", $post->id], "method" => "POST", "class" => "text-right"])); ?>

                            <?php echo e(Form::hidden("_method", "DELETE")); ?>

                            <button type="submit" class="btn btn-danger">Delete</button>
                        <?php echo e(Form::close()); ?>

                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    <?php else: ?>
        <p>No post found</p>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mysites\lsapp\resources\views/posts/show.blade.php ENDPATH**/ ?>