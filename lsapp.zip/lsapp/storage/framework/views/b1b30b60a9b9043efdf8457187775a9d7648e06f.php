<?php $__env->startSection("content"); ?>
<br/>
    <h1>Create Post</h1>
    <?php echo e(Form::open(["action" => "PostsController@store", "method" => "POST", "enctype" => "multipart/form-data"])); ?>

        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" class="form-control" name="title" id="title" aria-describedby="titleHelp" placeholder="Enter the title" maxlength="191">
        </div>
        <div class="form-group">
            <label for="body">Body</label>
            <textarea class="form-control" name="body" id="article-ckeditor" rows="5" placeholder="Enter the body of the post"></textarea>
        </div>
        <div class="form-group">
            <label for="body">Image</label>
            <br/>
            <input type="file" class="dropify" name="cover_image"/>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    <?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts/app", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\mysites\lsapp\resources\views/posts/create.blade.php ENDPATH**/ ?>