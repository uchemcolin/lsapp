@extends("layouts/app")

@section("content")
<br/>
    @if(!empty($post))
        <a href="/posts" class="btn btn-dark">Back</a>
        <h1>{{$post->title}}</h1>
        <div>
            <img class="w-100" src="/storage/cover_images/{{$post->cover_image}}"/>
            {!!$post->body!!}
        </div>
        <hr/>
        <small>Written on {{$post->created_at}} by {{$post->user->name}}</small>
        <hr/>
        @if(!Auth::guest())
            @if(Auth::user()->id == $post->user_id)
                <div class="row">
                    <div class="col-md-6">
                        <a href="/posts/{{$post->id}}/edit" class="btn btn-primary">Edit</a>
                    </div>
                    <div class="col-md-6">
                        {{ Form::open(["action" => ["PostsController@destroy", $post->id], "method" => "POST", "class" => "text-right"]) }}
                            {{Form::hidden("_method", "DELETE")}}
                            <button type="submit" class="btn btn-danger">Delete</button>
                        {{ Form::close() }}
                    </div>
                </div>
            @endif
        @endif
    @else
        <p>No post found</p>
    @endif

@endsection