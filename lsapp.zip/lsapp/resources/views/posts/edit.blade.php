@extends("layouts/app")

@section("content")
<br/>
    <h1>Edit Post</h1>
    {{ Form::open(["action" => ["PostsController@update", $post->id], "method" => "POST", "enctype"=> "multipart/form-data"]) }}
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" class="form-control" name="title" id="title" aria-describedby="titleHelp" placeholder="Enter the title" maxlength="191" value="{{$post->title}}">
        </div>
        <div class="form-group">
            <label for="body">Body</label>
            <textarea class="form-control" name="body" id="article-ckeditor" rows="5" placeholder="Enter the body of the post">{{$post->body}}</textarea>
        </div>
        <div class="form-group">
            <label for="body">Image</label>
            <br/>
            <input type="file" class="dropify" name="cover_image"/>
        </div>
        {{Form::hidden("_method", "PUT")}}
        <button type="submit" class="btn btn-primary">Update</button>
    {{ Form::close() }}
@endsection