@extends("layouts/app")

@section("content")
<br/>
    <h1>Create Post</h1>
    {{ Form::open(["action" => "PostsController@store", "method" => "POST", "enctype" => "multipart/form-data"]) }}
        <div class="form-group">
            <label for="title">Title</label>
            <input type="text" class="form-control" name="title" id="title" aria-describedby="titleHelp" placeholder="Enter the title" maxlength="191">
        </div>
        <div class="form-group">
            <label for="body">Body</label>
            <textarea class="form-control" name="body" id="article-ckeditor" rows="5" placeholder="Enter the body of the post"></textarea>
        </div>
        <div class="form-group">
            <label for="body">Image</label>
            <br/>
            <input type="file" class="dropify" name="cover_image"/>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    {{ Form::close() }}
@endsection