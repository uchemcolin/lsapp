@extends("layouts/app")
    @section("content")
        <br/>
        <div class="row">
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <div class="jumbotron text-center">
                    <h1 class="display-4">Welcome to Laravel</h1>
                    <p class="lead">This is the homepage</p>
                    <a class="btn btn-primary btn-lg" href="/login" role="button">Login</a>
                    <a class="btn btn-success btn-lg" href="/register" role="button">Sign Up</a>
                </div>
            </div>
            <div class="col-md-2"></div>
        </div>
    @endsection
