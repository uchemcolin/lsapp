@extends("layouts/app")
    @section("content")
        <h1>Services</h1>
        <ul class="list-group">
            @foreach($designs as $design)
                <li class="list-group-item">{{$design}}</li>
            @endforeach
        </ul>
    @endsection
