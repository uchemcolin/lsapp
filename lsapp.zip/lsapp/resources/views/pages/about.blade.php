@extends("layouts/app")
    @section("content")
        <h1>About</h1>
        <p>Re-learning Laravel</p>
    @endsection
